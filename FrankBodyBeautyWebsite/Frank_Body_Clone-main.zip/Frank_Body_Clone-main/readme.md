# <img src="https://res.cloudinary.com/crunchbase-production/image/upload/c_lpad,h_170,w_170,f_auto,b_white,q_auto:eco,dpr_1/v1438842049/auk7ayohemudyedrknde.png" width="25px"/> Frank Body Clone

<p>Frank Body is an e-commerce company, It sells beauty, and Makeup products across websites, mobile apps and 100+ offline stores. In 2020, I don’t take myself too seriously but I’m serious about the right thing.
That's why over 6 million babes have fallen in love with me.</p>

<p>Several years ago in a coffee shop, five friends had a drink and an idea: a humble coffee scrub. Their mission was to remove the hyperbole that saturates the skincare industry and make clean skincare fun. So they called me frank and I've been getting babes dirty ever since.
That simple, that good.</p>

<br>

<div align="center">
  <img  src="https://invitationdigital-res-1.cloudinary.com/image/upload/q_auto,f_auto,fl_strip_profile/Frank_banner" height="390px" width="100%"/>
  </div>
  
 # 🌟 Objective : <br>
 
 <p>Our objective is to replicate the original site with all the functionalities and design elements. We aim to create the best clone of the website using the skills we have learnt through Masai School.</p>
 
 
 # Tech Stack
  <div><img src="https://cdn-icons-png.flaticon.com/512/1048/1048877.png" width="15px"/> REACT</div>
  <div><img src="https://cdn-icons-png.flaticon.com/512/732/732190.png" width="15px"/> CSS</div>
  <div><img src="https://upload.wikimedia.org/wikipedia/commons/4/49/Redux.png" width="15px"/> Redux</div>
  <div><img src="https://cdn-icons-png.flaticon.com/512/718/718064.png" width="15px"/> LOCALSTORAGE</div>
  <div><img src="https://cdn-icons-png.flaticon.com/512/541/541488.png" width="15px"/> JSON-SERVER</div>
  
  <br>
  
# <img src="https://cdn-icons-png.flaticon.com/512/1534/1534938.png" width="25px"/> Team Members 
 
 | Name            | Contribution                                                                |
| ----------------- | ------------------------------------------------------------------ |
|<a href = "https://github.com/yug0231" > Yugal </a> | Landing Page |
| <a href = "https://github.com/Adil-khan-007" > Adil Khan </a>| Cart Page|
|<a href = "https://github.com/vaddadiPhani" > Bharat </a>| Login / Signup |
| <a href = "https://github.com/Mr-raaz" >Anshu Raj </a> | Shop , Product , Product Description ,Checkout , Payment , Profile , About , Contact|
 
 <br>
 
 # 🔹 Landing Page 
 <p>Landing Page has Login Signup / Search bar /  Cart and Trending Feature Which helps users to pick what They want Easily...</p>
 <img src="https://lh3.googleusercontent.com/u/0/drive-viewer/AFDK6gMgt1-QrxC8AOZQIbvTaqK7EC57FISabnApeWhJQVRIEtPO0l0KozkCNLNqPYZl_Jk35wyNSK6wj6X7unrYGwGE2byaUA=w1920-h972"/>
 
 # 🔹 Login / SignUp 
 <p></p>
 <img src="https://lh3.googleusercontent.com/u/0/drive-viewer/AFDK6gM1i7iRbKfazq-4IVzos7cRybi93R-vbpnyvsX_EB0mUOlKo4K4Cokws6zNfCgAMYVvsphqoQKVACLybaWMx7C_8RV5Vg=w1920-h972"/>
 
 # 🔹 Product Page
 <p></p>
 <img src="https://lh3.googleusercontent.com/u/0/drive-viewer/AFDK6gPmTf1_JTxaRwLHcspiXGye3CPtgrCfN-jpERR31zth4ajzFI1IaJdqYirtGN_5ubGaAOJBDYz7T31y61zGRqd0D4O5tA=w1920-h972"/>
 
 # 🔹 Product Description
 <p></p>
 <img src="https://lh3.googleusercontent.com/u/0/drive-viewer/AFDK6gOOmZkHYoWbWcI_pcskkrfpe_uPvyuKmVXD-xbH0xDF6BbaSVJqgv-cZACpNwc40CjWucrIi-HZG8m6D4Fr7jFFPMTgRw=w1920-h972"/>
 
  # 🔹 Cart Page
 <p></p>
 <img src="https://lh3.googleusercontent.com/u/0/drive-viewer/AFDK6gMBBzFOxgh-Ww99Xk-zIFKHIOIbKOBer77-XMwbeBd7GtgOIb2XnVDAHmJ3phOONxe6gwg18nbBz5HUcPI7i_eLPqAhow=w1920-h972"/>
 
  # 🔹 Payment Page
 <p></p>
 <img src="https://lh3.googleusercontent.com/u/0/drive-viewer/AFDK6gMsj-sNvn5dCTCpxESNGhXlvPRHkKo2RNS2wmmJKu7HlQsFBCrIqwUrfPIZstymlTCBfXuPg4s89Wc2U4JOeYS0AD46-A=w1920-h972"/>
 
 # 🔹 Shop Page
 <p></p>
 <img src="https://lh3.googleusercontent.com/u/0/drive-viewer/AFDK6gOe52u_JiW2MGEqWmJDbPd2_aL2HCM3dwhcCteOpY6FbHQ-H5M1841vCQY0TcfLxR5NzYJMWLUOrcZLwyvh9c8s8BU2ZA=w1920-h972"/>
 
 # 🔹 About Page
 <p></p>
 <img src="https://lh3.googleusercontent.com/u/0/drive-viewer/AFDK6gOPanyfXJQAUnFNHLjvoXz8tf4hCLkf4suMEceS7sr1Wuz1CWGOQAfGT0QbZgRBqvAYl-ynKCB6yoY91sqgIA_Dd5DrtQ=w1920-h972"/>
 
 # 🔹 Contact Page
 <p></p>
 <img src="https://lh3.googleusercontent.com/u/0/drive-viewer/AFDK6gPmAbtTU5462iSA4yx1C_OG6GxFzSNiL2D5oDiwr811XyqZY4_npxgZ3bHMoNb37sRl-lmjdj63cA_5ydrv9s0dZZ7-Lw=w1920-h972"/>
 
    
 # <img src="https://cdn-icons-png.flaticon.com/512/1934/1934019.png" width="25px"/> Challenges :
 
 <p> 1. As every journey has some challenges and so was ours. In our team, all of the members were not familiar with each other so it was difficult for all of us to communicate and collaborate, there were some moments when members were not able to communicate with each other and had a conflict and it was hard for everyone to handle these conflicts. </p>
 
 <p> 2. Another problem was to merge all of the files in a proper sequence which was again a difficult task for us because while merging and connecting all the pages some of the pages had the same name, and while running the site it was redirecting to some other pages so it was difficult to find the location and to rename the file.</p>
 <p> 3. All of Us were not very confident in React, throughout the devlopment We were facing issue in implementing redux part but we helped each other and got rid of from the problem and successfully completed our Project..</p>
 
 
 # 🚀 Demo :
 
 <p><a href ="https://darling-sorbet-a495bc.netlify.app/" ><img src = "https://camo.githubusercontent.com/59cde2396da07f6c391795028e4350eb3a99c0186d55161807728d44200c6959/68747470733a2f2f6170692e6e65746c6966792e636f6d2f6170692f76312f6261646765732f62363534633934652d303861362d346237392d623434332d3738333735383162316438642f6465706c6f792d737461747573"/></a></p>
 
  
  
